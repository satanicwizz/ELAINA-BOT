#!/bin/bash
npm install --legacy-peer-deps
npm start